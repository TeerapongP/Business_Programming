﻿using System;

namespace Lecture2
{
    class Program
    {
        

        static void Main(string[] args)
        {

            //variable declaration
            int user_input = 0;
            int input_number = 0;
            int input_number2 = 0;
            int result = 0;
            String con_user = "";

            do
            {
                //output Display
                Console.WriteLine("Press any following key to perform an arithmetic operation: \n");
                Console.WriteLine("1.Addition");
                Console.WriteLine("2.Subtraction");
                Console.WriteLine("3.Multipliation");
                Console.WriteLine("4.Division");

                user_input = int.Parse(Console.ReadLine());

                //Loop
                while (user_input > 4)
                {
                    Console.WriteLine("Enter Number 1-4 : ");
                    user_input = int.Parse(Console.ReadLine());
                }

                //Condition
                if (user_input == 1)
                {
                    Console.WriteLine("Enter Number1 : ");
                    input_number = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Number2 : ");
                    input_number2 = int.Parse(Console.ReadLine());
                    result = input_number + input_number2;


                    Console.WriteLine("{0} + {1} = {2}", input_number, input_number2, result);
                }


                else if (user_input == 2)
                {
                    Console.WriteLine("Enter Number1 : ");
                    input_number = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Number2 : ");
                    input_number2 = int.Parse(Console.ReadLine());
                    result = input_number - input_number2;


                    Console.WriteLine("{0} - {1} = {2}", input_number, input_number2, result);
                }

                else if (user_input == 3)
                {
                    Console.WriteLine("Enter Number1 : ");
                    input_number = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Number2 : ");
                    input_number2 = int.Parse(Console.ReadLine());
                    result = input_number * input_number2;


                    Console.WriteLine("{0} * {1} = {2}", input_number, input_number2, result);
                }

                else
                {
                    Console.WriteLine("Enter Number1 : ");
                    input_number = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Number2 : ");
                    input_number2 = int.Parse(Console.ReadLine());
                    double result1 = input_number / input_number2;


                    Console.WriteLine("{0} / {1} = {2}", input_number, input_number2, result1);
                }

                Console.WriteLine("Do you want to continue again (Y/N)?");
                con_user = Console.ReadLine().ToUpper();
            }
            while (con_user != "N");

        }
    }
}
 